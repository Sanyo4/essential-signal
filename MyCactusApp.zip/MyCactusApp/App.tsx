import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ActivityIndicator,
  NativeModules, StatusBar, AppState, ToastAndroid, ScrollView, 
  TextInput, Alert, Platform, KeyboardAvoidingView, LayoutAnimation, UIManager
} from 'react-native';
import { CactusLM } from 'cactus-react-native';

const { TextStreamModule } = NativeModules;

// Enable LayoutAnimation for Android
if (Platform.OS === 'android') {
  if (UIManager.setLayoutAnimationEnabledExperimental) {
    UIManager.setLayoutAnimationEnabledExperimental(true);
  }
}

// --- CONFIGURATION ---
const MODELS = {
  MAIN: { id: 'qwen3-0.6', name: 'CORE_UNIT', desc: 'Qwen3 (0.6B)' }
};

const DEFAULTS = {
  REFINE: "/no_think You are a Formatting Machine. You do not converse.\n\nInstructions:\n1. Read the [USER DRAFT].\n2. Rewrite it to be clear and kind (max 2 sentences).\n3. Use [SCREEN CONTEXT] to match the vibe (casual/formal) ONLY. Do NOT add facts from the context.\n4. Do NOT output introductions or explanations.\n\nRequired Output Format:\nREPLY: [Rewritten text as the person replying]",
  TONE: "/no_think You are a Semantic Analyzer. You do not summarize events.\n\nInstructions:\n1. Identify the emotional intent of the other person in [SCREEN CONTEXT].\n2. Output 1 short sentence of analysis.\n3. Output 1 suggested reply.\n\nRequired Output Format:\nANALYSIS: [One sentence semantic analysis]\nREPLY: [One sentence suggested response as the person replying]"
};

const cleanModelOutput = (rawOutput: string): string => {
  if (!rawOutput) return "";
  let cleaned = rawOutput.replace(/<think>[\s\S]*?<\/think>/g, '');
  cleaned = cleaned.replace('<|im_end|>', '');
  return cleaned.trim();
};

// --- VISUAL NOISE COMPONENT (White Digital Wave) ---
const ProcessingVisual = () => {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const interval = setInterval(() => setTick(t => t + 1), 80);
    return () => clearInterval(interval);
  }, []);

  return (
    <View style={styles.visualContainer}>
      {[...Array(5)].map((_, i) => {
         const randomHeight = Math.max(10, Math.random() * 50);
         const randomOpacity = Math.random() > 0.5 ? 1.0 : 0.3;
         return (
            <View key={i} style={{
                width: 6,
                height: randomHeight,
                backgroundColor: '#FFFFFF',
                opacity: randomOpacity,
                borderRadius: 0 
            }} />
         );
      })}
    </View>
  );
};

function App(): React.JSX.Element {
  const [viewMode, setViewMode] = useState<'MENU' | 'SETTINGS' | 'RESULT' | 'DOWNLOADING'>('MENU');
  
  // Data
  const [scrapedContext, setScrapedContext] = useState<string | null>(null);
  const [userDraft, setUserDraft] = useState<string>(""); 
  const [refinePrompt, setRefinePrompt] = useState(DEFAULTS.REFINE);
  const [tonePrompt, setTonePrompt] = useState(DEFAULTS.TONE);

  // Results
  const [analysisText, setAnalysisText] = useState<string>("");
  const [replyText, setReplyText] = useState<string>("");
  const [isThinking, setIsThinking] = useState(false);
  
  // System
  const [downloadStatus, setDownloadStatus] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const appState = useRef(AppState.currentState);

  const changeView = (mode: 'MENU' | 'SETTINGS' | 'RESULT' | 'DOWNLOADING') => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setViewMode(mode);
  };

  useEffect(() => {
    StatusBar.setBarStyle('light-content');
    if (Platform.OS === 'android') StatusBar.setBackgroundColor('black');

    const checkPersistence = async () => {
      const ready = await TextStreamModule.checkModelStatus(MODELS.MAIN.id);
      setDownloadStatus(ready);
      if (!ready) changeView('SETTINGS');
    };

    const checkForData = async () => {
      try {
        const data = await TextStreamModule.getSharedText();
        if (data && data.content && data.canReplace) {
             setScrapedContext(data.content);
             ToastAndroid.show("SIGNAL_ACQUIRED", ToastAndroid.SHORT);
        }
      } catch (e) { console.error(e); }
    };

    checkPersistence();
    checkForData();
    
    const subscription = AppState.addEventListener('change', nextAppState => {
      if (appState.current.match(/inactive|background/) && nextAppState === 'active') checkForData();
      appState.current = nextAppState;
    });
    return () => subscription.remove();
  }, [scrapedContext]);

  const handleRunPipeline = async (modeKey: 'REFINE' | 'TONE') => {
    if (!downloadStatus) {
      Alert.alert("SYSTEM_ERR", "CORE MISSING.");
      return;
    }
    if (modeKey === 'REFINE' && !userDraft.trim()) {
      Alert.alert("INPUT_ERR", "DRAFT REQUIRED.");
      return;
    }

    changeView('RESULT'); 
    setAnalysisText("");
    setReplyText("");
    setIsThinking(true);

    try {
      const mainModel = new CactusLM({ model: MODELS.MAIN.id });
      const activePrompt = modeKey === 'REFINE' ? refinePrompt : tonePrompt;
      
      let systemPrompt = `Task: ${activePrompt}\n\n`;
      if (scrapedContext) systemPrompt += `=== CONTEXT_DATA ===\n${scrapedContext}\n====================\n`;
      const userPrompt = modeKey === 'REFINE' ? `=== USER_INPUT ===\n${userDraft}` : "GENERATE_OUTPUT";

      const result = await mainModel.complete({
        messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }],
      });

      const cleaned = cleanModelOutput(result.response);
      const regex = /ANALYSIS:\s*([\s\S]*?)\s*REPLY:\s*([\s\S]*)/i;
      const match = cleaned.match(regex);

      LayoutAnimation.configureNext(LayoutAnimation.Presets.spring); 
      if (match && match.length >= 3) {
          setAnalysisText(match[1].trim());
          setReplyText(match[2].trim());
      } else {
          if (cleaned.toLowerCase().includes("reply:")) {
              const parts = cleaned.split(/REPLY:/i);
              setAnalysisText(parts[0].replace(/ANALYSIS:/i, '').trim());
              setReplyText(parts[1].trim());
          } else {
              setAnalysisText(""); 
              setReplyText(cleaned);
          }
      }

    } catch (error: any) {
      setAnalysisText("FATAL_ERR");
      setReplyText(error.message);
    } finally {
        setIsThinking(false);
    }
  };

  const handleDownload = async () => {
    changeView('DOWNLOADING');
    setDownloadProgress(0);
    try {
      const cactusLM = new CactusLM({ model: MODELS.MAIN.id });
      const interval = setInterval(() => setDownloadProgress(p => Math.min(p + 0.1, 0.9)), 500);
      await cactusLM.download();
      clearInterval(interval);
      setDownloadProgress(1.0);
      await TextStreamModule.markModelReady(MODELS.MAIN.id);
      setDownloadStatus(true);
      setTimeout(() => changeView('MENU'), 500);
    } catch (e: any) {
      Alert.alert("NET_FAIL", e.message);
      changeView('SETTINGS');
    }
  };

  const handleCopy = () => {
    if (!replyText) return;
    TextStreamModule.copyToClipboard(replyText);
    ToastAndroid.show("COPIED", ToastAndroid.SHORT);
    setTimeout(() => TextStreamModule.closeOverlay(), 300);
  };

  // --- LOGIC: MUTUALLY EXCLUSIVE BUTTONS ---
  const hasText = userDraft.trim().length > 0;
  
  // 1. Show REFINE if user has typed something
  const canRefine = hasText;
  
  // 2. Show DECODE only if text box is EMPTY (and we have context)
  const canAnalyze = !hasText && !!scrapedContext; 

  const DashedLine = () => (
    <View style={{height: 1, width: '100%', overflow: 'hidden', marginVertical: 15}}>
      <View style={{borderWidth: 1, borderColor: '#333', borderStyle: 'dashed', borderRadius: 1}} />
    </View>
  );

  return (
    <View style={styles.container}>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={styles.dynamicCard}>
        
        {/* HEADER */}
        <View style={styles.headerRow}>
           <Text style={styles.brandTitle}>ESSENTIAL <Text style={styles.redText}>SIGNAL</Text></Text>
           {viewMode === 'MENU' && (
             <TouchableOpacity onPress={() => changeView('SETTINGS')}>
               <Text style={styles.iconText}>( SETTINGS )</Text>
             </TouchableOpacity>
           )}
        </View>

        <DashedLine />

        {/* LOADING STATE */}
        {viewMode === 'DOWNLOADING' && (
          <View style={styles.centerContent}>
            <ProcessingVisual />
            <View style={styles.progressBar}><View style={[styles.progressFill, { width: `${downloadProgress * 100}%` }]} /></View>
          </View>
        )}

        {/* SETTINGS */}
        {viewMode === 'SETTINGS' && (
          <View>
            <Text style={styles.sectionTitle}>[ SYSTEM_CONFIG ]</Text>
            <View style={styles.settingRow}>
                <View>
                    <Text style={styles.monoTextBold}>{MODELS.MAIN.name}</Text>
                    <Text style={styles.monoTextSmall}>{MODELS.MAIN.desc}</Text>
                </View>
                <TouchableOpacity 
                    style={[styles.outlineBtn, downloadStatus ? {borderColor: '#333'} : {borderColor: '#D71921'}]}
                    onPress={handleDownload}
                    disabled={downloadStatus}
                >
                    <Text style={[styles.btnText, downloadStatus ? {color: '#333'} : {color: '#D71921'}]}>
                        {downloadStatus ? "ACTIVE" : "INSTALL"}
                    </Text>
                </TouchableOpacity>
            </View>
            <DashedLine />
            <View style={{maxHeight: 250}}>
                <ScrollView>
                    <Text style={styles.sectionTitle}>[ PROMPT_OVERRIDE ]</Text>
                    <Text style={styles.label}>:: REFINE_LOGIC</Text>
                    <TextInput style={styles.promptInput} multiline value={refinePrompt} onChangeText={setRefinePrompt} />
                    <Text style={styles.label}>:: DECODE_LOGIC</Text>
                    <TextInput style={styles.promptInput} multiline value={tonePrompt} onChangeText={setTonePrompt} />
                </ScrollView>
            </View>
            <View style={{marginTop: 15}}>
                <TouchableOpacity style={styles.solidBtn} onPress={() => changeView('MENU')}>
                    <Text style={styles.solidBtnText}>SAVE & EXIT</Text>
                </TouchableOpacity>
            </View>
          </View>
        )}

        {/* MENU */}
        {viewMode === 'MENU' && (
          <View>
            <View style={[styles.statusBox, scrapedContext ? {borderColor: '#D71921'} : {borderColor: '#333'}]}>
                <Text style={[styles.monoTextSmall, scrapedContext ? {color: '#D71921'} : {color: '#666'}]}>
                    STATUS: {scrapedContext ? "SIGNAL_LOCKED" : "NO_SIGNAL"}
                </Text>
            </View>
            
            <Text style={styles.label}>:: INPUT_DRAFT</Text>
            <TextInput
                style={styles.inputCompact}
                multiline
                placeholderTextColor="#333"
                placeholder="Write here..."
                value={userDraft}
                onChangeText={setUserDraft}
            />

            <View style={styles.gridContainer}>
                {/* REFINE - Active only if text exists */}
                <TouchableOpacity 
                    style={[styles.gridBtn, !canRefine && styles.disabledBtn]} 
                    onPress={() => handleRunPipeline('REFINE')}
                    disabled={!canRefine}
                >
                    <Text style={[styles.gridBtnText, !canRefine && {color: '#333'}]}>REFINE</Text>
                    {canRefine && <View style={styles.activeDot} />}
                </TouchableOpacity>

                {/* DECODE - Active only if text is EMPTY */}
                <TouchableOpacity 
                    style={[styles.gridBtn, !canAnalyze && styles.disabledBtn]} 
                    onPress={() => handleRunPipeline('TONE')}
                    disabled={!canAnalyze}
                >
                    <Text style={[styles.gridBtnText, !canAnalyze && {color: '#333'}]}>DECODE</Text>
                    {canAnalyze && <View style={styles.activeDot} />}
                </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.closeBtn} onPress={() => TextStreamModule.closeOverlay()}>
                <Text style={styles.closeText}>CLOSE_SESSION</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* RESULT */}
        {viewMode === 'RESULT' && (
          <View>
            <Text style={styles.sectionTitle}>[ OUTPUT ]</Text>
            
            <ScrollView style={{maxHeight: 250, marginVertical: 10}}>
                {isThinking ? (
                    <View style={{padding: 20}}>
                         <ProcessingVisual />
                    </View>
                ) : (
                    <View>
                        {analysisText.length > 0 && (
                            <View style={{marginBottom: 15}}>
                                <Text style={styles.label}>:: SEMANTIC_DECODE</Text>
                                <Text style={styles.resultText}>"{analysisText}"</Text>
                            </View>
                        )}
                        <Text style={styles.label}>:: SUGGESTED_REPLY</Text>
                        
                        <TouchableOpacity style={styles.resultBox} onPress={handleCopy}>
                            <Text style={styles.resultTextHigh}>{replyText}</Text>
                            <View style={styles.copyTag}>
                                <Text style={styles.copyText}>[ COPY ]</Text>
                            </View>
                        </TouchableOpacity>

                    </View>
                )}
            </ScrollView>
            
            <DashedLine />

            <TouchableOpacity style={styles.outlineBtnFull} onPress={() => changeView('MENU')} disabled={isThinking}>
                <Text style={styles.btnText}>RETURN</Text>
            </TouchableOpacity>
          </View>
        )}
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent', justifyContent: 'center', alignItems: 'center', padding: 20 },
  
  dynamicCard: { 
    backgroundColor: '#000000', 
    borderWidth: 1, 
    borderColor: '#333', 
    padding: 20, 
    width: '100%', 
    maxWidth: 360, 
    minHeight: 200, 
    elevation: 20,
    overflow: 'hidden' 
  },
  
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  brandTitle: { fontFamily: 'monospace', fontSize: 16, fontWeight: 'bold', color: '#FFFFFF', letterSpacing: 1 },
  redText: { color: '#D71921' },
  iconText: { fontFamily: 'monospace', fontSize: 12, color: '#666' },

  sectionTitle: { fontFamily: 'monospace', color: '#666', fontSize: 10, marginBottom: 10 },
  label: { fontFamily: 'monospace', color: '#666', fontSize: 10, marginBottom: 5, marginTop: 10 },
  monoText: { fontFamily: 'monospace', color: '#FFF', fontSize: 14 },
  monoTextBold: { fontFamily: 'monospace', color: '#FFF', fontSize: 14, fontWeight: 'bold' },
  monoTextSmall: { fontFamily: 'monospace', color: '#666', fontSize: 10 },
  
  // VISUAL LOADER
  visualContainer: { flexDirection: 'row', gap: 4, height: 50, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },

  statusBox: { borderWidth: 1, padding: 8, marginBottom: 15, borderStyle: 'dashed' },
  inputCompact: { backgroundColor: '#111', borderWidth: 1, borderColor: '#333', color: '#FFF', fontFamily: 'monospace', padding: 10, height: 80, textAlignVertical: 'top', fontSize: 14 },
  promptInput: { backgroundColor: '#0A0A0A', borderWidth: 1, borderColor: '#222', color: '#CCC', fontFamily: 'monospace', padding: 10, minHeight: 80, textAlignVertical: 'top', fontSize: 11, marginBottom: 10 },

  gridContainer: { flexDirection: 'row', gap: 10, marginTop: 20, marginBottom: 5 },
  gridBtn: { flex: 1, height: 50, borderWidth: 1, borderColor: '#FFF', justifyContent: 'center', alignItems: 'center', backgroundColor: '#000' },
  gridBtnText: { color: '#FFF', fontFamily: 'monospace', fontWeight: 'bold', fontSize: 16 },
  disabledBtn: { borderColor: '#333' },
  activeDot: { width: 4, height: 4, backgroundColor: '#D71921', position: 'absolute', top: 5, right: 5 },

  outlineBtn: { paddingVertical: 6, paddingHorizontal: 12, borderWidth: 1, borderColor: '#FFF' },
  outlineBtnFull: { width: '100%', paddingVertical: 12, borderWidth: 1, borderColor: '#333', alignItems: 'center', marginTop: 10 },
  solidBtn: { backgroundColor: '#FFF', paddingVertical: 12, alignItems: 'center' },
  solidBtnText: { color: '#000', fontWeight: 'bold', fontFamily: 'monospace' },
  btnText: { color: '#FFF', fontFamily: 'monospace', fontSize: 12 },
  
  closeBtn: { alignItems: 'center', padding: 10 },
  closeText: { color: '#D71921', fontFamily: 'monospace', fontSize: 10 },

  // RESULT & COPY STYLES
  resultBox: { backgroundColor: '#111', borderWidth: 1, borderColor: '#333', padding: 15, marginTop: 5, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  resultText: { color: '#999', fontFamily: 'monospace', fontSize: 12, fontStyle: 'italic' },
  resultTextHigh: { color: '#FFF', fontFamily: 'monospace', fontSize: 14, flex: 1 },
  
  // STYLIZED COPY BUTTON
  copyTag: { 
    marginLeft: 10,
    backgroundColor: '#000', 
    borderWidth: 1, 
    borderColor: '#333', 
    paddingHorizontal: 8, 
    paddingVertical: 4 
  },
  copyText: { 
    color: '#D71921', 
    fontFamily: 'monospace', 
    fontSize: 10, 
    fontWeight: 'bold' 
  },

  centerContent: { alignItems: 'center', padding: 20, gap: 10 },
  progressBar: { width: '100%', height: 2, backgroundColor: '#333', marginTop: 10 },
  progressFill: { height: '100%', backgroundColor: '#D71921' },
  settingRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 10 },
});

export default App;