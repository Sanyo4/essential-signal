package com.mycactusapp;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.util.Log;
import android.view.WindowManager;
import android.view.Gravity;

import com.facebook.react.bridge.ActivityEventListener;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.BaseActivityEventListener;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.UiThreadUtil;

import android.os.Handler;
import android.os.Looper;

public class TextStreamModule extends ReactContextBaseJavaModule {
    private static final String MODULE_NAME = "TextStreamModule";
    private static final String TAG = "TextStreamModule";
    private static final String PREFS_NAME = "NeuroPrefs";

    private final ActivityEventListener mActivityEventListener = new BaseActivityEventListener() {
        @Override
        public void onActivityResult(Activity activity, int requestCode, int resultCode, Intent data) {}
    };

    TextStreamModule(ReactApplicationContext context) {
        super(context);
        context.addActivityEventListener(mActivityEventListener);
    }

    @Override
    public String getName() { return MODULE_NAME; }

    // --- ACCESSIBILITY / TILE SCRAPER LOGIC ---

    @ReactMethod
    public void getSharedText(Promise promise) {
        Activity activity = getCurrentActivity();
        if (activity == null) { promise.resolve(null); return; }

        Intent intent = activity.getIntent();
        WritableMap map = Arguments.createMap();

        // 1. Check for text passed via NeuroTileService (Quick Settings Tile)
        if (intent.hasExtra(Intent.EXTRA_PROCESS_TEXT)) {
            String text = intent.getStringExtra(Intent.EXTRA_PROCESS_TEXT);
            map.putString("content", text);
            map.putBoolean("canReplace", true);
            
            // Remove so it doesn't trigger again on reload
            intent.removeExtra(Intent.EXTRA_PROCESS_TEXT);
            
            promise.resolve(map);
            return;
        }

        // 2. Check for standard Android Share Sheet
        String action = intent.getAction();
        String type = intent.getType();

        if (Intent.ACTION_SEND.equals(action) && "text/plain".equals(type)) {
            map.putString("content", intent.getStringExtra(Intent.EXTRA_TEXT));
            map.putBoolean("canReplace", false);
            promise.resolve(map);
        } else {
            promise.resolve(null);
        }
    }

    // --- LEGACY SCRAPER (If used from Button instead of Tile) ---

    @ReactMethod
    public void setOverlayPassThrough(boolean enable) {
        UiThreadUtil.runOnUiThread(() -> {
            Activity activity = getCurrentActivity();
            if (activity == null) return;
            
            try {
                android.view.Window window = activity.getWindow();
                WindowManager.LayoutParams params = window.getAttributes();

                if (enable) {
                    // Minimize window to 1px to allow Accessibility to see behind it
                    params.width = 1;
                    params.height = 1;
                    params.gravity = Gravity.TOP | Gravity.START;
                    params.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                    params.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                    window.setAttributes(params);
                    Log.d(TAG, "Overlay Minimized");
                } else {
                    // Restore
                    params.width = WindowManager.LayoutParams.MATCH_PARENT;
                    params.height = WindowManager.LayoutParams.MATCH_PARENT;
                    params.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                    params.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                    window.setAttributes(params);
                    Log.d(TAG, "Overlay Restored");
                }
            } catch (Exception e) {
                Log.e(TAG, "Error resizing window: " + e.getMessage());
            }
        });
    }

    @ReactMethod
    public void fetchScreenText(Promise promise) {
        try {
            if (NeuroAccessibilityService.instance == null) {
                promise.reject("SERVICE_OFF", "Accessibility Service is not enabled.");
                return;
            }

            // 1. Shrink Window
            setOverlayPassThrough(true);

            // 2. Wait for focus shift
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                try {
                    // 3. Scrape
                    String content = NeuroAccessibilityService.getScreenContent();
                    
                    // 4. Restore
                    setOverlayPassThrough(false);

                    if (content == null || content.isEmpty()) {
                        promise.resolve("No text detected.");
                    } else {
                        promise.resolve(content);
                    }
                } catch (Exception e) {
                    setOverlayPassThrough(false);
                    promise.reject("ERROR", e.getMessage());
                }
            }, 800); 

        } catch (Exception e) {
            promise.reject("ERROR", e.getMessage());
        }
    }

    // --- UTILS ---
    @ReactMethod
    public void checkModelStatus(String modelId, Promise promise) {
        SharedPreferences prefs = getReactApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        promise.resolve(prefs.getBoolean("ready_" + modelId, false));
    }

    @ReactMethod
    public void markModelReady(String modelId) {
        SharedPreferences prefs = getReactApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean("ready_" + modelId, true).apply();
    }

    @ReactMethod
    public void copyToClipboard(String text) {
        ClipboardManager clipboard = (ClipboardManager) getReactApplicationContext().getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("AI Response", text));
    }

    @ReactMethod
    public void closeOverlay() {
        Activity activity = getCurrentActivity();
        if (activity != null) activity.finish();
    }
}