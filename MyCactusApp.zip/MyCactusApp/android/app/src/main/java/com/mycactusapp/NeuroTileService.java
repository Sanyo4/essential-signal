package com.mycactusapp;

import android.content.Intent;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.util.Log;
import android.widget.Toast;

public class NeuroTileService extends TileService {
    @Override
    public void onClick() {
        super.onClick();
        Log.d("NeuroTile", "Tile Clicked");

        // 1. CHECK IF CLICK IS REGISTERED
        if (NeuroAccessibilityService.instance == null) {
            Toast.makeText(this, "⚠️ Service OFF. Toggle in Settings > Accessibility", Toast.LENGTH_LONG).show();
            return;
        }

        // 2. TRIGGER LOGIC
        NeuroAccessibilityService.instance.scheduleScrapeAndLaunch();
    }

    @Override
    public void onStartListening() {
        super.onStartListening();
        Tile tile = getQsTile();
        if (tile != null) {
            tile.setState(Tile.STATE_ACTIVE);
            tile.updateTile();
        }
    }
}