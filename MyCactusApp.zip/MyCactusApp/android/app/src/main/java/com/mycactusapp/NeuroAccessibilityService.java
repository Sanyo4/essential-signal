package com.mycactusapp;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Toast;
import java.util.List;

public class NeuroAccessibilityService extends AccessibilityService {
    public static NeuroAccessibilityService instance;
    private static final String TAG = "NeuroAccess";
    private int screenWidth;
    private int screenHeight;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
        Log.d(TAG, "Connected. Screen: " + screenWidth + "x" + screenHeight);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() { instance = null; }

    public void scheduleScrapeAndLaunch() {
        performGlobalAction(GLOBAL_ACTION_BACK); 
        Toast.makeText(this, "Scanning...", Toast.LENGTH_SHORT).show();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            String content = getScreenContent();
            
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            
            if (content != null && !content.isEmpty()) {
                intent.putExtra(Intent.EXTRA_PROCESS_TEXT, content);
            } else {
                intent.putExtra(Intent.EXTRA_PROCESS_TEXT, ""); // Empty string indicates failure
            }
            startActivity(intent);
        }, 1500); 
    }

    public static String getScreenContent() {
        if (instance == null) return null;
        StringBuilder sb = new StringBuilder();
        
        List<AccessibilityWindowInfo> windows = instance.getWindows();
        if (windows != null) {
            for (AccessibilityWindowInfo window : windows) {
                if (window == null) continue;
                if (window.getType() == AccessibilityWindowInfo.TYPE_APPLICATION) {
                    AccessibilityNodeInfo root = window.getRoot();
                    if (root != null) {
                        if (root.getPackageName() != null && root.getPackageName().toString().equals("com.mycactusapp")) {
                            root.recycle();
                            continue;
                        }
                        traverseNode(root, sb);
                        root.recycle();
                    }
                }
            }
        }
        return sb.toString();
    }

    private static void traverseNode(AccessibilityNodeInfo node, StringBuilder sb) {
        if (node == null) return;

        if (node.getText() != null && node.getText().length() > 0) {
            Rect rect = new Rect();
            node.getBoundsInScreen(rect);
            
            String prefix = "";
            
            if (instance != null && rect.width() > 0) {
                int centerX = rect.centerX();
                int centerY = rect.centerY();
                int screenCenter = instance.screenWidth / 2;
                
                // Logic 1: Header/Name detection (Top 15% of screen)
                if (centerY < (instance.screenHeight * 0.15)) {
                    prefix = "[HEADER]: ";
                } 
                // Logic 2: Chat Bubble detection (Me vs Them)
                else {
                    if (centerX > screenCenter) {
                        prefix = "[ME]: ";
                    } else {
                        prefix = "[THEM]: ";
                    }
                }
            }

            sb.append(prefix).append(node.getText()).append("\n");
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                traverseNode(child, sb);
                child.recycle();
            }
        }
    }
}